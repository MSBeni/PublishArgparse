class AddSimple:
    def __init__(self):
        pass

    def sayhello(self, name):
        return f"Hello to you, {name}"
        # return name

    def print_till100(self):
        lst = []
        for i in range(1, 101):
            lst.append(i)
        return lst

