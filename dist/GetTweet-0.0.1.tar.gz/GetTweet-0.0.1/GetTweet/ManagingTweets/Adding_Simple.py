class AddSimple:
    def __init__(self):
        pass

    def print_1(self, args):
        if args:
            for i in range(1, 101):
                return i

    def print_till100(self):
        lst = []
        for i in range(1, 101):
            lst.append(i)
        return lst

