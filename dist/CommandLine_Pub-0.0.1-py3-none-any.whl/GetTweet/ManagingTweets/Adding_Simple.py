class AddingSimple:
    def __init__(self):
        pass

    def print_till_100(self):
        for i in range(1, 101):
            return i

